﻿namespace MenuProgramEB
{
    partial class AddItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addItemlabel = new System.Windows.Forms.Label();
            this.SizeLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.kindLabel = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.addonLabel = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // addItemlabel
            // 
            this.addItemlabel.AutoSize = true;
            this.addItemlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.addItemlabel.ForeColor = System.Drawing.Color.Snow;
            this.addItemlabel.Location = new System.Drawing.Point(20, 18);
            this.addItemlabel.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.addItemlabel.Name = "addItemlabel";
            this.addItemlabel.Size = new System.Drawing.Size(231, 46);
            this.addItemlabel.TabIndex = 0;
            this.addItemlabel.Text = "Add Course";
            // 
            // SizeLabel
            // 
            this.SizeLabel.AutoSize = true;
            this.SizeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.SizeLabel.ForeColor = System.Drawing.Color.Snow;
            this.SizeLabel.Location = new System.Drawing.Point(6, 73);
            this.SizeLabel.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.SizeLabel.Name = "SizeLabel";
            this.SizeLabel.Size = new System.Drawing.Size(83, 22);
            this.SizeLabel.TabIndex = 1;
            this.SizeLabel.Text = "Difficulty:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(91, 75);
            this.textBox1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(67, 20);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(177, 75);
            this.textBox2.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(67, 20);
            this.textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(268, 75);
            this.textBox3.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(67, 20);
            this.textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(360, 75);
            this.textBox4.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(67, 20);
            this.textBox4.TabIndex = 5;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(452, 75);
            this.textBox5.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(67, 20);
            this.textBox5.TabIndex = 6;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(91, 109);
            this.textBox6.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(67, 20);
            this.textBox6.TabIndex = 7;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(177, 109);
            this.textBox7.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(67, 20);
            this.textBox7.TabIndex = 8;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(268, 109);
            this.textBox8.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(67, 20);
            this.textBox8.TabIndex = 9;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(360, 109);
            this.textBox9.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(67, 20);
            this.textBox9.TabIndex = 10;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(452, 109);
            this.textBox10.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(67, 20);
            this.textBox10.TabIndex = 11;
            // 
            // kindLabel
            // 
            this.kindLabel.AutoSize = true;
            this.kindLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.kindLabel.ForeColor = System.Drawing.Color.Snow;
            this.kindLabel.Location = new System.Drawing.Point(12, 148);
            this.kindLabel.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.kindLabel.Name = "kindLabel";
            this.kindLabel.Size = new System.Drawing.Size(68, 25);
            this.kindLabel.TabIndex = 12;
            this.kindLabel.Text = "Class:";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(91, 151);
            this.textBox11.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(67, 20);
            this.textBox11.TabIndex = 13;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(177, 151);
            this.textBox12.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(67, 20);
            this.textBox12.TabIndex = 14;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(268, 151);
            this.textBox13.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(67, 20);
            this.textBox13.TabIndex = 15;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(360, 151);
            this.textBox14.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(67, 20);
            this.textBox14.TabIndex = 16;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(452, 151);
            this.textBox15.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(67, 20);
            this.textBox15.TabIndex = 17;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(91, 182);
            this.textBox16.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(67, 20);
            this.textBox16.TabIndex = 18;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(177, 182);
            this.textBox17.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(67, 20);
            this.textBox17.TabIndex = 19;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(268, 182);
            this.textBox18.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(67, 20);
            this.textBox18.TabIndex = 20;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(360, 182);
            this.textBox19.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(67, 20);
            this.textBox19.TabIndex = 21;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(452, 182);
            this.textBox20.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(67, 20);
            this.textBox20.TabIndex = 22;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(91, 213);
            this.textBox21.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(67, 20);
            this.textBox21.TabIndex = 23;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(177, 213);
            this.textBox22.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(67, 20);
            this.textBox22.TabIndex = 24;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(268, 213);
            this.textBox23.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(67, 20);
            this.textBox23.TabIndex = 25;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(360, 213);
            this.textBox24.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(67, 20);
            this.textBox24.TabIndex = 26;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(452, 213);
            this.textBox25.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(67, 20);
            this.textBox25.TabIndex = 27;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(91, 243);
            this.textBox26.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(67, 20);
            this.textBox26.TabIndex = 28;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(177, 243);
            this.textBox27.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(67, 20);
            this.textBox27.TabIndex = 29;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(268, 243);
            this.textBox28.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(67, 20);
            this.textBox28.TabIndex = 30;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(360, 243);
            this.textBox29.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(67, 20);
            this.textBox29.TabIndex = 31;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(452, 243);
            this.textBox30.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(67, 20);
            this.textBox30.TabIndex = 32;
            // 
            // addonLabel
            // 
            this.addonLabel.AutoSize = true;
            this.addonLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.addonLabel.ForeColor = System.Drawing.Color.Snow;
            this.addonLabel.Location = new System.Drawing.Point(12, 284);
            this.addonLabel.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.addonLabel.Name = "addonLabel";
            this.addonLabel.Size = new System.Drawing.Size(73, 25);
            this.addonLabel.TabIndex = 33;
            this.addonLabel.Text = "Extras:";
            this.addonLabel.Click += new System.EventHandler(this.addonLabel_Click);
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.Color.White;
            this.saveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveButton.Location = new System.Drawing.Point(484, 483);
            this.saveButton.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(79, 32);
            this.saveButton.TabIndex = 64;
            this.saveButton.Text = "SAVE";
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(452, 434);
            this.textBox31.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(67, 20);
            this.textBox31.TabIndex = 84;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(360, 434);
            this.textBox32.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(67, 20);
            this.textBox32.TabIndex = 83;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(268, 434);
            this.textBox33.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(67, 20);
            this.textBox33.TabIndex = 82;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(177, 434);
            this.textBox34.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(67, 20);
            this.textBox34.TabIndex = 81;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(91, 434);
            this.textBox35.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(67, 20);
            this.textBox35.TabIndex = 80;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(452, 404);
            this.textBox36.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(67, 20);
            this.textBox36.TabIndex = 79;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(360, 404);
            this.textBox37.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(67, 20);
            this.textBox37.TabIndex = 78;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(268, 404);
            this.textBox38.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(67, 20);
            this.textBox38.TabIndex = 77;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(177, 404);
            this.textBox39.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(67, 20);
            this.textBox39.TabIndex = 76;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(91, 404);
            this.textBox40.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(67, 20);
            this.textBox40.TabIndex = 75;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(452, 374);
            this.textBox41.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(67, 20);
            this.textBox41.TabIndex = 74;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(360, 374);
            this.textBox42.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(67, 20);
            this.textBox42.TabIndex = 73;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(268, 374);
            this.textBox43.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(67, 20);
            this.textBox43.TabIndex = 72;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(177, 374);
            this.textBox44.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(67, 20);
            this.textBox44.TabIndex = 71;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(91, 374);
            this.textBox45.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(67, 20);
            this.textBox45.TabIndex = 70;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(452, 343);
            this.textBox46.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(67, 20);
            this.textBox46.TabIndex = 69;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(360, 343);
            this.textBox47.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(67, 20);
            this.textBox47.TabIndex = 68;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(268, 343);
            this.textBox48.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(67, 20);
            this.textBox48.TabIndex = 67;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(177, 343);
            this.textBox49.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(67, 20);
            this.textBox49.TabIndex = 66;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(91, 343);
            this.textBox50.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(67, 20);
            this.textBox50.TabIndex = 65;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(452, 314);
            this.textBox51.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(67, 20);
            this.textBox51.TabIndex = 94;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(360, 314);
            this.textBox52.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(67, 20);
            this.textBox52.TabIndex = 93;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(268, 314);
            this.textBox53.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(67, 20);
            this.textBox53.TabIndex = 92;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(177, 314);
            this.textBox54.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(67, 20);
            this.textBox54.TabIndex = 91;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(91, 314);
            this.textBox55.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(67, 20);
            this.textBox55.TabIndex = 90;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(452, 284);
            this.textBox56.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(67, 20);
            this.textBox56.TabIndex = 89;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(360, 284);
            this.textBox57.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(67, 20);
            this.textBox57.TabIndex = 88;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(268, 284);
            this.textBox58.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(67, 20);
            this.textBox58.TabIndex = 87;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(177, 284);
            this.textBox59.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(67, 20);
            this.textBox59.TabIndex = 86;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(91, 284);
            this.textBox60.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(67, 20);
            this.textBox60.TabIndex = 85;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(328, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 31);
            this.label1.TabIndex = 95;
            this.label1.Text = "Name:";
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(407, 31);
            this.nameBox.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(111, 20);
            this.nameBox.TabIndex = 96;
            // 
            // AddItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(574, 533);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.addonLabel);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.kindLabel);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.SizeLabel);
            this.Controls.Add(this.addItemlabel);
            this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(590, 572);
            this.MinimumSize = new System.Drawing.Size(590, 572);
            this.Name = "AddItem";
            this.ShowIcon = false;
            this.Text = "AddItem";
            this.Load += new System.EventHandler(this.AddItem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label addItemlabel;
        private System.Windows.Forms.Label SizeLabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label kindLabel;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label addonLabel;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nameBox;
    }
}