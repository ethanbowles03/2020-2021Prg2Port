import java.util.Scanner;
import java.util.Random;
import java.lang.Math;

public class ArrayAlgorithms{
  public int sum(int[] array){
    int sum = 0;

    for(int i = 0; i < array.length; i++){
      sum += array[i];
    }
    return sum;
  }

  public int average(int[] array){
    int count = 0;
    int average = sum(array) / array.length;

    return average;
  }

  public int min(int[] array){
    int min = array[0];

      for(int i = 0; i<array.length; i++ ) {
         if(array[i]<min) {
            min = array[i];
         }
      }
      return min;
  }

  public int max(int[] array){
    int max = 0;

      for(int i=0; i<array.length; i++ ) {
         if(array[i]>max) {
            max = array[i];
         }
      }
      return max;
  }

  public void intSep(int[] array){
    for(int i = 0; i < array.length; i++){
      System.out.print(array[i] + " ");
    }
    System.out.println("");
  }

  public void search(int val, int[] array){
    int finalCount = 500;
    int count = 0;
    for(int i = 0; i < array.length; i++){
      if(array[i] ==  val){
        finalCount = count;
      }
      count++;
    }
    if(count == 500){
      System.out.println("Number not found");
    }else{
      System.out.println("Number " + val + " is in the " + (finalCount + 1) + "th positition");
    }
  }

  public void remove(int pos, int[] array){
    int[] newArray = new int[array.length - 1];
    int val = 0;
    for(int i = 0, k = 0; i < array.length; i++){
      if(i == pos){
        val = array[i];
        continue;
      }else{
        newArray[k++] = array[i];
      }
    }
    System.out.println("You removed the value " + val + " from the " + pos + "th positition");
  }

  public void add(int val, int pos, int[] array){
    int[] newArray = new int[array.length + 1];
    for(int i = 0, k = 0; i < newArray.length; i++){
      if(pos == i){
        newArray[i] = val;
      }else{
        newArray[i] = array[k];
      }
    }
    System.out.println("You added the value " + val + " to the " + pos + "th positition");
    
  }

  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    Random rand = new Random();
    int upper = 200;
    int searchVal = 15;
    int[] randomArray = new int[100];

    for(int i = 0; i < 100; i++){
      int random = rand.nextInt(upper);
      if(random == 0){
        random = 1;
      }
      random = random - 100;
      randomArray[i] = random;
    }

    ArrayAlgorithms m = new ArrayAlgorithms();

    System.out.println("Sum: " + m.sum(randomArray));
    System.out.println("Average: " + m.average(randomArray));
    System.out.println("Min: " + m.min(randomArray));
    System.out.println("Max: " + m.max(randomArray));
    System.out.print("Elements Separated: ");
    m.intSep(randomArray);
    m.search(searchVal, randomArray);
    m.remove(searchVal, randomArray);
    m.add(70, 0, randomArray);
  }
}
