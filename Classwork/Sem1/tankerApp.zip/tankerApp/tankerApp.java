import java.util.Scanner;

public class tankerApp {
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);

        int tanker = 11000;
        boolean validFluid = false;
        boolean validAge = false;
        int fluidOunces = 0;
        int yearsLived = 0;

        while(!validFluid){
          System.out.println("How many ounces of fluid do you consume per day? ");
          fluidOunces = sc.nextInt();
          if(fluidOunces > 0){
            validFluid = true;

          } else {
            validFluid = false;
          }
        }
          while(!validAge){
            System.out.println("How many years are you expecting to live? ");
            yearsLived = sc.nextInt();
            if(yearsLived > 0){
              validAge = true;

            } else {
              validAge = false;
            }
          }

          sc.close();

          float totalGallons = ((yearsLived * 365) * fluidOunces) / 128;
          float tankersUsed = totalGallons/tanker;
          System.out.println("You will consume around " + tankersUsed + " tankers of fluid in your lifetime");
        }
      }
