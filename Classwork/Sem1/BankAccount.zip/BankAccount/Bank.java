/**
* @author Etham Bowles
* @since   2020-10-6
*/

public class Bank{

  /**
  *This is the main method
  * @param args Unused
  * @return Nothing
  * @exception IOException On input error.
  * @see IOException
  */
  public static void main(String[] args){
    BankAccount account1 = new BankAccount();
    BankAccount account2 = new BankAccount(500.0);

    System.out.println("Account1's starting balance: " + account1.getBalance());
    System.out.println("Account2's starting balance: " + account2.getBalance());

    account1.deposit(500);
    account2.deposit(700);

    System.out.println("Account1 deposits 500 dollars making their new balance: " + account1.getBalance());
    System.out.println("Account2 deposits 700 dollars making their new balance: " + account2.getBalance());

    account1.deductMonthlyCharge();
    account2.deductMonthlyCharge();

    System.out.println("After a month a fee is deducted from bank account1 leaving the balance at: " + account1.getBalance());
    System.out.println("After a month a fee is deducted from bank account2 leaving the balance at: " + account2.getBalance());

    System.out.println("Account1 withdraws " + account1.withdraw(200) + " dollars with a 2 percent transaction fee leaving the balance of the account at: " + account1.getBalance());
    System.out.println("Account1 withdraws " + account2.withdraw(300) + " dollars with a 2 percent transaction fee leaving the balance of the account at: " + account2.getBalance());

  }
}
