/**
* @author Etham Bowles
* @since   2020-10-6
*/

public class BankAccount{
  private double balance;
  private double fee = 0.02;
  private int monthlyCharge = 50;

  /**
  *default constructor
  */
  BankAccount(){
    this.balance = 0;
  }

  /**
  *Second constructor for passing in initial balance
  *@param initialValue sets custom initial value of the balance
  */
  BankAccount(double initialValue){
    this.balance = initialValue;
  }

  /**
  *Adds the amount being deposited to the balance
  *@param amount sets value of amount being deposited
  */
  public void deposit(double amount){
    this.balance = this.balance + amount;
  }

  /**
  *Subtracts the amount being withdrawn and the fee
  *@param amount sets value of amount being withdrawn
  *@return amount returns the amount being withdrawn
  */
  public double withdraw(double amount){
    this.balance = this.balance - (amount + setTransactionFee(amount));
    return amount;
  }

  /**
  *Reports the current balance
  *@return balance to user
  */
  public double getBalance(){
    return this.balance;
  }

  /**
  *Takes in amount being withdrawn and multiplies it by a fee percent
  *@param transFee gives the initial withdraw value
  *@return transFee total amount of fee
  */
  public double setTransactionFee(double transFee){
    transFee = transFee * this.fee;
    return transFee;
  }

  /**
  *Deducts 50 dollars from balance
  */
  public void deductMonthlyCharge(){
    this.balance = this.balance - monthlyCharge;
  }
}
