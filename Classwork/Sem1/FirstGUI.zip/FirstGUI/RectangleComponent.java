import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.*;
import java.awt.geom.Line2D;
import javax.swing.*;
import java.util.*;

public class RectangleComponent extends JComponent{
  public void paintComponent(Graphics g){
    Graphics2D g2 = (Graphics2D) g;

    Day today = new Day();
    Scanner in = new Scanner(System.in);

    int currentYear = today.getYear();
    int currentMonth = today.getMonth();
    int currentDay = today.getDate();

    int famNum = 6;

    while(famNum > 5){
      System.out.println("How many people are in your family(1-5)");
      famNum = in.nextInt();
    }

    int x = 650;

    for(int i = 0; i < famNum; i++){
      System.out.println("What it the name of your family member: ");
      String famName = in.nextLine();
      System.out.println("What is the month they were born: ");
      int famMonth = in.nextInt();
      System.out.println("What is the day they were born: ");
      int famDay = in.nextInt();

      Day bDay = new Day(currentYear,famMonth,famDay);
      int untilBDay = (365 - today.daysFrom(bDay)) + 1;

      untilBDay *= 4.9315;

      System.out.println(untilBDay);

      Rectangle rect = new Rectangle(100,x,untilBDay,100);
      g2.setColor(Color.RED);
      g2.fill(rect);

      x -= 150;
    }

    Line2D.Double seg1 = new Line2D.Double(100,800,1900,800);
    g2.setColor(Color.BLACK);
    g2.draw(seg1);

  }
}
