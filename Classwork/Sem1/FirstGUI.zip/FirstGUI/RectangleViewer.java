import javax.swing.*;

public class RectangleViewer{
  public static void main(String args[]){
    JFrame frame = new JFrame();
    frame.setSize(2000,900);
    frame.setTitle("RectangleGUI");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    RectangleComponent component = new RectangleComponent();
    frame.add(component);

    frame.setVisible(true);
  }
}
