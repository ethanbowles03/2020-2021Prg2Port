/**
*@param power sets the power of the mircowave
*@param cookTime sets the duration of the microwave runtime
*/
public class Main{
  /**
  *This is the main method
  * @param args Unused
  * @return Nothing
  * @exception IOException On input error.
  * @see IOException
  */
  public static void main(String[] args){
    Microwave microwave = new Microwave(2,30);

    microwave.increaseTime();
    microwave.increaseTime();
    microwave.selectPower(1);
    System.out.println(microwave.start());
    microwave.reset();
    microwave.increaseTime();
    microwave.selectPower(2);
    System.out.println(microwave.start());
  }
}
