/**
* @author Etham Bowles
* @since   2020-10-8
*/

public class Microwave{
  private int powerlevel;
  private int time;

  /**
  *default constructor sets time to 0 and power to one
  */
  public Microwave(){
    this.powerlevel = 1;
    this.time = 0;
  }

  /**
  *@param power sets the power of the mircowave
  *@param cookTime sets the duration of the microwave runtime
  */
  public Microwave(int power, int cookTime){
    if(power == 2) {
      this.powerlevel = 2;
    }else {
      this.powerlevel = 1;
    }
    this.time = cookTime;
  }

  /**
  *Increases time by 30 seconds
  */
  public void increaseTime(){
    this.time += 30;
  }

  /**
  *@param power sets the power level of the microwave
  */
  public void selectPower(int power){
    if(power == 2) {
      this.powerlevel = 2;
    }else {
      this.powerlevel = 1;
    }
  }

  /**
  *Resets the power of the mircowave to 0
  */
  public void reset(){
    this.time = 0;
    this.powerlevel = 1;
  }

  /**
  *@return the final result of the power level and cooking time as a string for the user to print
  */
  public String start(){

    return "Cooking for " + this.time + " seconds at level " + this.powerlevel;
  }


}
