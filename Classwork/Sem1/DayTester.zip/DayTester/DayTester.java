import java.util.*;

public class DayTester{
  public static void main(String args[]){
    Scanner in = new Scanner(System.in);
    Day today = new Day();

    int year = 0;
    int month = 0;
    int day = 0;

    System.out.println("Enter your birth year below: ");
    year = in.nextInt();
    System.out.println("Enter your birth month below: ");
    month = in.nextInt();
    System.out.println("Enter your birth day below: ");
    day = in.nextInt();

    Day birthday = new Day(year, month, day);

    int daysAlive = today.daysFrom(birthday);
    System.out.println("You have been alive " + daysAlive + " days");
  }
}
