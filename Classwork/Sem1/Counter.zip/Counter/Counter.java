/**
* @author Etham Bowles
* @since   2020-9-30
*/

public class Counter{
  private int value;

  /**
  *default constructor
  */
  public Counter(){
    value = 0;
  }

  /**
  *Second constructor for passing in int
  *@param value This sets the initial value of the tally
  */
  public Counter(int initialValue){
    value = initialValue;
  }

  /**
  * Adds 1 to the value
  */
  public void click(){
    value++;
  }

  /**
  * @return value
  */
  public int getValue(){
    return value;
  }


  /**
  * Subtracts 1 to the value
  */
  public void undo(){
    value--;
  }


  /**
  * Resets the value
  */
  public void reset(){
    value = 0;
  }
}
