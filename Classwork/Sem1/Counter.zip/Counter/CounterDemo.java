/**
* @author Etham Bowles
* @since   2020-9-30
*/

public class CounterDemo{

  /**
  *This is the main method
  * @param args Unused
  * @return Nothing
  * @exception IOException On input error.
  * @see IOException
  */

  public static void main(String[] args){
    Counter tally = new Counter();
    Counter tally2 = new Counter(234);

    //Unit test on first constructor

    System.out.println("Initial Value: " + tally.getValue());
    tally.click();
    tally.click();
    tally.click();
    System.out.println("New Value: " + tally.getValue());

    tally.undo();

    System.out.println("Undone Value: " + tally.getValue());

    tally.reset();

    System.out.println("Reset Value: " + tally.getValue());

    //Unit test on 2nd constructor

    System.out.println("Initial Value of second constructor: " + tally2.getValue());
    tally2.click();
    tally2.click();
    tally2.click();
    System.out.println("New Value of second constructor: " + tally2.getValue());

    tally2.undo();

    System.out.println("Undone Value of second constructor: " + tally2.getValue());

    tally2.reset();

    System.out.println("Reset Value of second constructor: " + tally2.getValue());

  }
}
