import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import javax.swing.JComponent;

/*
   A component that draws an alien face
*/
public class Ticket extends JComponent
{
   public void paintComponent(Graphics g)
   {
      // Recover Graphics2D
      Graphics2D g2 = (Graphics2D) g;

      int x = 250;
      int boxX = 10;
      int x

      // Prints lines
      for(int i = 0; i < 4; i++){
        Line2D.Double mouth = new Line2D.Double(x, 0, x, 1000);
        g2.setColor(Color.RED);
        g2.draw(mouth);
        x = x + 250;
      }

      //Loops sections
      for(int i = 0; i < 4; i ++){
        //Loops lines
        for(){
          //loops colums
          for(){

          }
        }
        x = x + 250;
      }
   }
}
