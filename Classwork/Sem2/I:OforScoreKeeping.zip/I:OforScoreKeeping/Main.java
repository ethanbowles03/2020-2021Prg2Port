import java.util.Scanner;
import java.util.Random;
import java.time.*;
import java.io.*;
import java.text.DecimalFormat;

class Main {
  private static int finalLoop = 0;
  public static void main(String[] args) {
    boolean loop = true;
    Scanner s = new Scanner(System.in);
    while(loop){
      Random random = new Random();
      int randNum = random.nextInt(100);
      int guess = 0;
      int attempts = 0;
      String username = "";
      Scanner sc = new Scanner(System.in);

      System.out.println("Welcome to the Number Guessing Game!");
      System.out.println("Please enter your name before playing: ");
      username = sc.nextLine();

      findHighScore();
      System.out.println("--------------------------");
      System.out.println("The Current High Score is (Name, Date, Time, Attempts):");
      printHighScore();
      System.out.println("--------------------------");

      LocalTime time1 = LocalTime.now();
      double sSeconds =  Double.parseDouble(time1.toString().substring(6));
      int sMinutes = Integer.parseInt(time1.toString().substring(3,5));

      System.out.println("Guess a number between 1 and 100");
      guess = sc.nextInt();
      while(guess != randNum){
        if(randNum>guess){
          System.out.println("Your guess was too low, try again:");
          guess = sc.nextInt();
        }else if(randNum<guess){
          System.out.println("Your guess was too high, try again:");
          guess = sc.nextInt();
        }
        attempts++;
      }


      LocalTime time2 = LocalTime.now();
      double eSeconds =  Double.parseDouble(time2.toString().substring(6));
      int eMinutes = Integer.parseInt(time2.toString().substring(3,5));
      double finalSeconds = eSeconds - sSeconds;
      int finalMinutes = eMinutes - sMinutes;

      String finalSec = "";
      String finalMin = "";
      if(finalSeconds < 0){
        finalSeconds = sSeconds - eSeconds;
      }

      if(finalMinutes != 0){
        finalMinutes = finalMinutes * (-1);
      }

      if(finalMinutes < 10){
        finalMin = "0" + String.valueOf(finalMinutes);
      }

      String textOutput = "";
      String outtime = time2.toString().substring(0,8);
      DecimalFormat df = new DecimalFormat("##.###");
      finalSeconds = Double.valueOf(df.format(finalSeconds));
      textOutput = username + ", " + outtime + ", " + finalMin + ":" + finalSeconds + ", " + attempts;

      System.out.println("You win! You guessed it in " + attempts + " tries!");
      writeToFile(textOutput);

      System.out.println("Would you like to continue:(Y/N)");
      String choice = s.nextLine();
      if(choice.equals("Y") || choice.equals("N")){

      }else{
        loop = false;
      }
    }
  }

  private static void findHighScore(){
    try {
      File file = new File("scores.txt");
      Scanner myReader = new Scanner(file);
      int lastMinute = 0;
      double lastSecond = 0;
      int loopCount = 0;
      while (myReader.hasNextLine()) {
        int count = 0;
        String data = myReader.nextLine();
        String timeScore = "";
        for(int i = 0; i < 100; i++){
          if(count == 2){
            timeScore = data.substring(i + 1, i + 10);
            count++;
          }else if(count == 3){
            continue;
          }
          String ch = data.substring(i, i+1);
          if(ch.equals(",")){
            count++;
          }
        }
        int nMinutes = Integer.parseInt(timeScore.substring(0,2));
        double nSeconds =  Double.parseDouble(timeScore.substring(3));

        if(nMinutes < lastMinute){
          lastMinute = nMinutes;
          lastSecond = nSeconds;
          finalLoop = loopCount;
        }else if(nMinutes == lastMinute){
          if(nSeconds < lastSecond){
            lastSecond = nSeconds;
            finalLoop = loopCount;
          }
        }
        loopCount++;
      }
      myReader.close();
    }

    catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }

  public static void printHighScore(){
    String highScore = "";
    try {
      File file = new File("scores.txt");
      Scanner myReader = new Scanner(file);
      int count = 0;
      while (myReader.hasNextLine()) {
        highScore = myReader.nextLine();
        if(count == finalLoop){
          System.out.println(highScore);
          break;
        }
        count++;
      }
      myReader.close();
    }

    catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }

  private static void writeToFile(String in){
    try{
      File file = new File("scores.txt");
      FileWriter fr = new FileWriter(file, true);
      BufferedWriter br = new BufferedWriter(fr);
      br.write(in);

      br.close();
      fr.close();
    }catch (Exception e) {
      System.out.println("error");
    }
  }
}
