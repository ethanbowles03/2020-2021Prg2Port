import java.util.*;
import java.io.*;

public class Collections{

    private static Stack<Integer> sortStack(Stack<Integer> in){
      Stack<Integer> newStack = new Stack<Integer>();
        while(!in.isEmpty())
        {
            int temp = in.pop();
            while(!newStack.isEmpty() && newStack.peek() > temp){
            in.push(newStack.pop());
            }
            newStack.push(temp);
        }
        return newStack;
    }

    public static void main (String[] args)
    {
      Stack<Integer> stack = new Stack<Integer>();

        // Use add() method to add elements
        stack.push(10);
        stack.push(15);
        stack.push(30);
        stack.push(20);
        stack.push(5);

        System.out.println(stack);
        System.out.println(sortStack(stack));
    }
}
