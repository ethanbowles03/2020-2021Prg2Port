import javax.swing.*;
import java.awt.*;

public class Buttons{
  int buttonX = 0;
  int buttonY = 0;
  public void setButtonLocation(int x, int y){
    this.buttonX = x;
    this.buttonY = y;
  }
  public void printButton(){
    JButton button = new Button();
    button.SetBounds(buttonX, buttonY);
    frame.add(button);
  }
}
