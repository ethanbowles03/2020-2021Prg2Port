import javax.swing.*;
import java.awt.*;

public class Launchpad{
  public JFrame frame = new JFrame("Launchpad");
  public static void main(String[] args){
    Buttons btns = new Buttons();
    btns.setButtonLocation(100,100);
    btns.printButton();
    frame.setSize(1000,1000);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.getContentPane().setBackground(Color.BLACK);
    frame.setVisible(true);
  }
}
