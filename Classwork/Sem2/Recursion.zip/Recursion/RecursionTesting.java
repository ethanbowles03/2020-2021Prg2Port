import java.math.*;

public class RecursionTesting{
  public RecursionTesting(){
    System.out.println("Traditional Factorial: " + traditionalFactorial(10));
    System.out.println("Recusive Factorial: " + recursiveFactorial(10));
    System.out.println("Traditional Fibonacci: " + traditionalFibonacci(10));
    System.out.println("Recusive Fibonacci: " + recursiveFibonacci(10));
  }
  public static void main(String[] args){
    new RecursionTesting();
  }

  public BigDecimal traditionalFactorial(int n){
    BigDecimal factorial = BigDecimal.valueOf(1);
    for(int i = 0; i < n; i++){
      factorial = factorial.multiply(BigDecimal.valueOf(i + 1));
    }
    return factorial;
  }

  public BigDecimal recursiveFactorial(int n){
    if(n == 1){
      return BigDecimal.valueOf(1);
    }else{
      return recursiveFactorial(n-1).multiply(BigDecimal.valueOf(n));
    }
  }

  public int traditionalFibonacci(int n){
    int ptr1 = 1;
    int ptr2 = 1;
    int temp = 0;
    int finalInt = 0;
    for (int i = 0; i < n; i++) {
        finalInt = ptr1 + ptr2;
        temp = ptr1;
        ptr1 = ptr2;
        ptr2 = temp + ptr2;
    }
    return temp;
  }

  public BigDecimal recursiveFibonacci(int n){
    if(n == 0)
      return BigDecimal.valueOf(0);
    else if(n == 1)
      return BigDecimal.valueOf(1);
    else
      return recursiveFibonacci(n - 1).add(recursiveFibonacci(n - 2));
  }
}
