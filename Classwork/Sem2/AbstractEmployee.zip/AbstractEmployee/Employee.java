/**
   An Item represents a product for sale.
*/
public class Employee implements Measurable
{
   private double anualWage;
   private double wageWithBenefits;

   /**
      Constructs an Employee.
      @param anual the retail price of this item.
      @param benefits the wholesale price of this item.
   */
   public Employee(double anual, double benefits)
   {
      anualWage = anual;
      wageWithBenefits = benefits;
   }

   public double getMeasure(){
      return wageWithBenefits - anualWage;
   }

}
