import java.util.*;

public class Tester{
  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter anual wage: ");
    double wage = sc.nextDouble();
    System.out.println("Enter anual wage with benefits: ");
    double benefits = sc.nextDouble();

    Employee e = new Employee(wage, benefits);
    System.out.println("Total benefits: " + e.getMeasure());
  }
}
