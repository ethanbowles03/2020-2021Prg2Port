// Made by Seth Mccullough

#ifndef PREFIX_H_
#define PREFIX_H_
#include <string>
#include <ctime>
#include <iostream>
#include <algorithm>

using namespace std;

class Prefix {
public:
	Prefix();
	string make();
	string func();
	string prefixDef;
	string prefix;
private:
};



#endif /* PREFIX_H_ */
