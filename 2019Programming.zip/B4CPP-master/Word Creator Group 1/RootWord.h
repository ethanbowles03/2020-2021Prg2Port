// Made by Parker Rowland

#ifndef ROOTWORD_H_
#define ROOTWORD_H_
#include <string>
#include <stdlib.h>
#include <time.h>
#include <iostream>

class RootWord {
public:
	RootWord();
	std::string Roots();
	std::string Definitions();
	std::string func();
	int randRoot();
private:
};

#endif /* ROOTWORD_H_ */
