#ifndef SWAMP_H_
#define SWAMP_H_
#include <ctime>

class swamp {
public:
	swamp();
	bool run();
private:
};



#endif /* SWAMP_H_ */
