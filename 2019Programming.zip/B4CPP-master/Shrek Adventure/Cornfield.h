#ifndef CORNFIELD_H_
#define CORNFIELD_H_
#include <ctime>

class Cornfield {
public:
	Cornfield();
	bool run();
private:
};


#endif /* CORNFIELD_H_ */
