/*
 * BattleArena.h
 *
 *  Created on: Feb 28, 2019
 *      Author: Jacob Schwartz
 */

#ifndef BATTLEARENA_H_
#define BATTLEARENA_H_

#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

class BattleArena {

public:
	BattleArena();
	bool fight();

private:
};

#endif /* BATTLEARENA_H_ */
