#ifndef SHERWOODFOREST_H_
#define SHERWOODFOREST_H_
#include <ctime>

class SherwoodForest {
public:
	SherwoodForest();
	bool run();
};


#endif /* SHERWOODFOREST_H_ */
