### Automated Teller

This project we will have an application where you can create or use an existing account to store and track Finances.  

## Gantt Chart

https://docs.google.com/spreadsheets/d/1Xyj491jKk7cVUhrTxa-1tCVXKSMoKESnCEz3voI0y0E/edit?usp=sharing


## Group Members

Zack, Nicholai, Jacob, Jerimiah, Mason, Ethan, Parker, and Seth

## Images

![m'lady](https://github.com/SkylineHigh/B4CPP/blob/master/Automated%20Teller/AutomatedDiagram.jpg)
![m'lady](https://github.com/SkylineHigh/B4CPP/blob/master/Automated%20Teller/bank.jpg)
