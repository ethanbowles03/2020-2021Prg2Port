### Castaway

This is a choose your own story kind of game where you become stranded on your boat, and your friend is stranded on a nearby island. You need to fix your boat or try to help him survive while dealing with issues like predatory creature hunting your friend.

## Group Members

Zack, Nicholai, Jacob, Jerimiah, Mason, Ethan, Parker, and Seth

# Images

![m'lady](https://github.com/SkylineHigh/B4CPP/blob/master/Lifeline/Lifeline%20GUI.jpg)
![m'lady](https://github.com/SkylineHigh/B4CPP/blob/master/Lifeline/Lifeline%20GUI%202.jpg)
