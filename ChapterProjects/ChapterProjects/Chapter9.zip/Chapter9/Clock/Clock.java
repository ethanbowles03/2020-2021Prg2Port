import java.time.*;
import java.time.temporal.*;

public class Clock{
  public int time = 0;

  public Clock(){
    this.time = 0;
  }

  public int getHours(){
    LocalTime lt = LocalTime.now();
    String hours = lt.toString().substring(0,2);
    int num = Integer.parseInt(hours) + time;
    if(num > 24){
      num = num - 24;
    }
    return num;
  }

  public int getMinutes(){
    LocalTime lt = LocalTime.now();
    String minutes = lt.toString().substring(3,5);
    int num = Integer.parseInt(minutes);
    return num;
  }

  public void getTime(){
    System.out.println(getHours() + ":" + getMinutes());
  }
}
