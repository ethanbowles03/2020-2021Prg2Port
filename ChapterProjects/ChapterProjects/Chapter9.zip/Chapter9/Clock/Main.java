public class Main{
  public static void main(String[] args){
    Clock c = new Clock();
    WorldClock wc = new WorldClock(3);

    c.getTime();
    wc.getTime();
  }
}
