public class WorldClock extends Clock{
  public WorldClock(int os){
    time = os;
  }
}
