import java.util.Scanner;

public class TheaterSeating{
  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);

    int[][] seating = new int[9][10];
    String[] alb = new String[] {"A","B","C","D","E","F","G","H","I"};
    String[] count = new String[] {"1","2","3","4","5","6","7","8","9","10"};

    //fills the first 3 columns
    for(int i = 0; i < 3; i++){
      for(int j = 0; j < 10; j++){
        seating[i][j] = 10;
      }
    }
    //fills the second 3 columns
    for(int i = 3; i < 6; i++){
      for(int j = 0; j < 10; j++){
        if(j == 0 || j == 1 || j == 8 || j == 9){
          seating[i][j] = 10;
        }else{
          seating[i][j] = 20;
        }
      }
    }

    //fills 7th row
    seating[6][0] = 20;
    seating[6][1] = 20;
    seating[6][2] = 30;
    seating[6][3] = 30;
    seating[6][4] = 40;
    seating[6][5] = 40;
    seating[6][6] = 30;
    seating[6][7] = 30;
    seating[6][8] = 20;
    seating[6][9] = 20;

    //fills 8th row
    seating[7][0] = 20;
    seating[7][1] = 30;
    seating[7][2] = 30;
    seating[7][3] = 40;
    seating[7][4] = 50;
    seating[7][5] = 50;
    seating[7][6] = 40;
    seating[7][7] = 30;
    seating[7][8] = 30;
    seating[7][9] = 20;

    //fills 9th row
    seating[8][0] = 30;
    seating[8][1] = 40;
    seating[8][2] = 50;
    seating[8][3] = 50;
    seating[8][4] = 50;
    seating[8][5] = 50;
    seating[8][6] = 50;
    seating[8][7] = 50;
    seating[8][8] = 40;
    seating[8][9] = 30;

    System.out.print("    ");
    for(int i = 0; i < 10; i++){
      System.out.print((i + 1) + "  ");
    }
    System.out.println("");
    System.out.println("");

    //prints the prices of the seats in array
    for(int i = 0; i < 9; i++){
      System.out.print(alb[i] + "   ");
      for(int j = 0; j < 10; j++){
        System.out.print(seating[i][j] + " ");
      }
      System.out.println("");
    }

    System.out.println("Based off of chart above you would like to search for a seat using: ");
    System.out.println("  1. Price");
    System.out.println("  2. Loaction");

    String choice = sc.nextLine();

    if(choice.equals("1")){
      System.out.println("Please enter a price you would like to search for: ");
      int price = sc.nextInt();
      System.out.println("The seats that cost " + price + " dollars are: ");
      for(int i = 0; i < 9; i++){
        for(int j = 0; j < 10; j++){
          if(price == seating[i][j]){
            System.out.print(alb[i] + count[j] + "  ");
          }
        }
      }
      System.out.println("");
    }
    else if(choice.equals("2")){
      System.out.println("Please enter a seat you would like to search for: (Use row and column together; all cap(EX. A2))");
      String seat = sc.nextLine();
      String row = seat.substring(0,1);
      String col = seat.substring(1);
      for(int i = 0; i < 9; i++){
        for(int j = 0; j < 10; j++){
          String column = Integer.toString(j+1);
          if(alb[i].equals(row) && column.equals(col)){
            System.out.println("The price of this seat is " + seating[i][j] + " dollars");
          }
        }
      }
    }else{
      System.out.println("Choice selected doesnt exist!");
    }
  }
}
