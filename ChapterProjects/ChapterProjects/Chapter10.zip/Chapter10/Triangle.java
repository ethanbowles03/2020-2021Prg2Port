import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.event.*;
import java.awt.geom.*;

public class Triangle extends JFrame implements ActionListener, MouseListener {
    private int x = 0;
    private int y = 0;

    private int x1 = 0;
    private int y1 = 0;
    private int x2 = 0;
    private int y2 = 0;
    private int x3 = 0;
    private int y3 = 0;
    private int count = 0;
    private boolean tri = false;

    public Triangle () {
        setSize(400,400);
        setBackground(Color.WHITE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addMouseListener(this);
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
              public void run() {
                   Triangle frame = new Triangle();
                   frame.setVisible(true);
              }
        });
    }

    public void actionPerformed(ActionEvent ae) {

    }

    @Override
    public void paint(Graphics g) {
      if(count == 1){
        removeTri();
      }
      drawCircle(x, y);
      if(tri == true){
        drawTriangle();
        tri = false;
      }
      if(count == 5){
        removeTri();
        count = 1;
      }
    }

    public void drawCircle(int x, int y) {
        Graphics g = this.getGraphics();
        g.setColor(Color.BLACK);
        g.fillOval(x, y, 6, 6);
        if(count == 1){
          x1 = x;
          y1 = y;
        }
        else if(count == 2){
          x2 = x;
          y2 = y;
        }
        else if(count == 3){
          x3 = x;
          y3 = y;
          tri = true;
        }
        System.out.println(count);
        count++;
    }

    public void drawTriangle(){
      Graphics g = this.getGraphics();
      g.setColor(Color.BLACK);
      g.drawLine(x1 + 3, y1 + 3, x2 + 3, y2 + 3);
      g.drawLine(x2 + 3, y2 + 3, x3 + 3, y3 + 3);
      g.drawLine(x3 + 3, y3 + 3, x1 + 3, y1 + 3);
    }

    public void removeTri(){
      Graphics g = this.getGraphics();
      g.setColor(Color.WHITE);
      g.fillRect(0,0,400,400);
    }

    public void mousePressed(MouseEvent e) {
      x = e.getX();
      y = e.getY();

      repaint();
    }

    public void mouseReleased(MouseEvent e) {

    }

    public void mouseEntered(MouseEvent e) {

    }

    public void mouseClicked(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }
}
