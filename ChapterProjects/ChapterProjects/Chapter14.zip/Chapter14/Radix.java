import java.io.*;
import java.util.*;
import java.lang.Math;

public class Radix{

  public static void main(String[] args){
    int arr[] = randArray(50);
    int length = arr.length;

    System.out.println("Before:");
    for(int i = 0; i < length; i++){
      System.out.print(arr[i] + " ");
    }
    System.out.println("");

    radix(arr, length);

    System.out.println("After:");
    for(int i = 0; i < length; i++){
      System.out.print(arr[i] + " ");
    }

    System.out.println("");
  }

  private static int[] randArray(int len){
    int array[] = new int[len];
    int max = 999;
    int min = 1;

    for(int i = 0; i < len; i++){
      array[i] = (int)Math.floor(Math.random()*(max-min+1)+min);
    }

    return array;
  }

  private static void radix(int arr[], int n){
    int max = findMax(arr, n);

    for (int exp = 1; max / exp > 0; exp *= 10){
      sort(arr, n, exp);
    }
  }

  private static void sort(int a[], int n, int exp){
    int out[] = new int[n];
    int i = 0;
    int count[] = new int[10];
    Arrays.fill(count, 0);

    for (i = 0; i < n; i++){
      count[(a[i] / exp) % 10]++;
    }

    for (i = 1; i < 10; i++){
      count[i] += count[i - 1];
    }

    for (i = n - 1; i >= 0; i--){
      out[count[(a[i] / exp) % 10] - 1] = a[i];
      count[(a[i] / exp) % 10]--;
    }

    for (i = 0; i < n; i++){
      a[i] = out[i];
    }
  }

  private static int findMax(int a[], int n){
    int x = a[0];
    for (int i = 1; i < n; i++){
      if (a[i] > x){
        x = a[i];
      }
    }
    return x;
  }
}
