//Author: Ethan Bowles
//Date: September 9, 2020
//This is an app that estimates the value of pi by using a series
//There user inputs the number of times they would like to run the loop which estimates
//the value of pi more accurately every run through

import java.util.Scanner;
import java.lang.Math;

public class piProject{

  public static void main(String args[]){
    //declares the variables used throughout all of the program
    int loopRun = 0;
    float x = 0;

    //creates a scanner object for input from the user
    Scanner in = new Scanner(System.in);

    //Gets input from the user
    System.out.println("Enter how many times you want to run the loop to estimate pi: ");
    loopRun = in.nextInt();

    //Runs the calculation as many times as the user asks
    for(int i = 0; i < loopRun; i++){
      //adds the previous value caclulated by loop to itself giving a more accurate estimation
      //calls calculatePi function
      x = x + calculatePi(i);
    }

    //Prints user their final estimation
    System.out.println("Your estimation of pi is: " + (x * 4));
  }

  //Calculate pi method that returns a fraction which will eventually be
  //added to the previous results to estimate the value of pi
  public static float calculatePi(float a){
    //declares variables used in function
    float pi = 0;
    int r = -1;
    double power = 0.0;
    double denominator = 0.0;

    //the power variable rotates the value of the fraction between 1 and negative 1
    power = Math.pow(r, a);
    denominator = (2 * a) + 1;

    //fraction gets smaller the further in the loop and rotates between positive and negative
    pi = (float)(power * (1 / denominator));

    //returns pi
    return pi;
  }

}
