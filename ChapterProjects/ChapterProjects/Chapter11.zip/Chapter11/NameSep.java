import java.io.*;
import java.util.*;

public class NameSep{
  public static void main(String[] args) throws Exception{
    HashSet<String> boyNames = new HashSet<String>();
    HashSet<String> girlNames = new HashSet<String>();

    File file = new File("BabyNames.txt");
    Scanner sc = new Scanner(file);

    while(sc.hasNext()){
      int id = sc.nextInt();
      String male = sc.next();
      int num1 = sc.nextInt();
      double num2 = sc.nextDouble();
      String female = sc.next();
      int num3 = sc.nextInt();
      double num4 = sc.nextDouble();

      boyNames.add(male);
      girlNames.add(female);
    }
    sc.close();
    writeToFile("boyNames.txt", boyNames);
    writeToFile("girlNames.txt", girlNames);
  }

  private static void writeToFile(String filename, HashSet<String> names)   throws Exception{
    File file = new File(filename);
    file.createNewFile();

    FileWriter fw = new FileWriter(filename);
    for(String name : names){
      fw.write(name);
      fw.write(System.getProperty( "line.separator" ));
    }
    fw.close();
  }
}
