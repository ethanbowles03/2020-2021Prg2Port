import java.util.*;

public class Palindrome{
  public static void main(String[] args){
    Scanner in = new Scanner(System.in);
    System.out.println("How many palidromes would you like to check?");
    int num = in.nextInt();
    int count = 0;
    for(int i = 1; i < num; i++){
      if(isPalindrome(i +  rev(i,0)) == true){
        System.out.println(i + " + " + rev(i,0) + " = " + (i +  rev(i,0)));
        count++;
      }
    }
    System.out.println("You found " + count + " palidromes!");
  }

  private static int rev(int n, int temp){
    if (n == 0){
      return temp;
    }else{
      temp = (temp * 10) + (n % 10);
      return rev(n / 10, temp);
    }
  }

  public static boolean isPalindrome(int num)
   {
      int equals = rev(num, 0);
      if(equals == num){
        return true;
      }else{
        return false;
      }
   }
}
