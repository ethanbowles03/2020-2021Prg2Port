import java.util.Scanner;

public class PhoneNumber{
  public static void main(String[] args){
    Scanner in = new Scanner(System.in);
    boolean loop = false;
    String pn = "";

    while(loop ==  false){
      System.out.println("Please enter a phone number below: ");
      pn = in.nextLine();
      if(pn.length() == 10){
        loop = true;
      }
    }

    String areaCode = "(" + pn.substring(0,3) + ") ";
    String threeNum = pn.substring(3,6);
    String lastNum = pn.substring(6);

    System.out.println("The modified phone number is: " + areaCode + threeNum + "-" + lastNum);
  }
}
