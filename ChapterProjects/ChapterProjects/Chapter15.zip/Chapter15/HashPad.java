import java.util.HashMap;
import java.util.Scanner;
import java.lang.Character;

public class HashPad{
  private static HashMap<Character,Character> keyPadEntry = new HashMap<Character,Character>();

  public HashPad(char space){
    char c;
    int key = 1;
    int count = 1;

    keyPadEntry.put(' ', space);
    key++;

    for(c = 'a'; c <= 'z'; c++){
      if(c == 's'){
        keyPadEntry.put(c,'7');
      }else if(c == 'z'){
        keyPadEntry.put(c,'9');
      }else{
        if(count%4 == 0){
          key++;
          count = 1;
        }
        keyPadEntry.put(c,Integer.toString(key).charAt(0));
        count++;
      }
    }
  }

  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    System.out.println("Would you like the space to be a Space or a 1(type 1 or 2):");
    System.out.println("  1. Space");
    System.out.println("  2. 1");
    int choice = sc.nextInt();
    if(choice == 1){
      new HashPad(' ');
    }else{
      new HashPad('1');
    }
    Scanner s = new Scanner(System.in);
    System.out.println("Enter the text you wish to be converted into a key pad entry: ");
    String text = s.nextLine();
    char[] ca = text.toCharArray();
    for(char c : ca){
      System.out.print(keyPadEntry.get(Character.toLowerCase(c)));
    }
    System.out.println();
  }
}
